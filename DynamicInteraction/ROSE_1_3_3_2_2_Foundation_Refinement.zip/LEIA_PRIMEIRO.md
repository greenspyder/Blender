# ROSE 1.3.3.2.2 · Foundation Refinement

Importe `project.godot` e execute o projeto para entrar diretamente no jogo.

- [Guia desta versão para jogar no Android e no PC](GUIA_FOUNDATION_1_3_3_2_2.md)
- [Auditoria, medições e capturas antes/depois](AUDITORIA_FOUNDATION_1_3_3_2_2.md)
- [Tutorial da interface, ações e personalizações](GUIA_GAMEPLAY_1_3_3_2.md)
- [Resultados de validação e limitações](VALIDACAO_1_3_3_2.md)
- [Referências posturais da 1.3.3.1](GUIA_POSTURAS_1_3_3_1.md)
- [Active Ragdoll da 1.3.3](GUIA_ACTIVE_RAGDOLL_1_3_3.md)

As instruções antigas de acesso a bancadas são históricas. A experiência principal agora inicia em `gameplay/main.tscn`; ferramentas técnicas ficam ocultas em Preferências → Mostrar ferramentas de desenvolvimento.

- [Tecidos físicos e personalizações](GUIA_TECIDOS_1_3_3_2_1.md)
- [Validação dos tecidos](VALIDACAO_TECIDOS_1_3_3_2_1.md)

- [Hotfix da resposta das roupas: diagnóstico e validação](HOTFIX_CLOTH_RESPONSE.md)
